// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAq-Lb6iDLUuUr0FZucWxhzA-RD57yDXbM",
    authDomain: "e-clinic-gh.firebaseapp.com",
    projectId: "e-clinic-gh",
    storageBucket: "e-clinic-gh.firebasestorage.app",
    messagingSenderId: "1011717061747",
    appId: "1:1011717061747:web:a2cd9bb4a9c5718e5fbe06"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Global variables
let currentUser = null;
let currentUserData = null;

// DOM elements
const loginBtn = document.getElementById('loginBtn');
const getStartedBtn = document.getElementById('getStartedBtn');
const loginModal = document.getElementById('loginModal');
const signupModal = document.getElementById('signupModal');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const dashboard = document.getElementById('dashboard');
const appointmentForm = document.getElementById('appointmentForm');
const logoutBtn = document.getElementById('logoutBtn');
const adminLink = document.getElementById('adminLink');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    // Set minimum date for appointments to today
    const today = new Date().toISOString().split('T')[0];
    const appointmentDateInput = document.getElementById('appointmentDate');
    if (appointmentDateInput) {
        appointmentDateInput.min = today;
    }

    // Auth state observer
    auth.onAuthStateChanged(handleAuthStateChange);
    
    // Setup modals
    setupModals();
    
    // Setup event listeners
    setupEventListeners();
    
    // Initialize sample data
    setTimeout(initializeSampleData, 2000);
});

// Event listeners setup
function setupEventListeners() {
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    if (signupForm) signupForm.addEventListener('submit', handleSignup);
    if (appointmentForm) appointmentForm.addEventListener('submit', handleAppointmentBooking);
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);
    if (loginBtn) loginBtn.addEventListener('click', () => showModal('loginModal'));
    if (getStartedBtn) getStartedBtn.addEventListener('click', () => showModal('signupModal'));
}

// Modal functions
function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.close');
    const signupLink = document.getElementById('signupLink');
    const loginLink = document.getElementById('loginLink');
    
    // Close modal when clicking X
    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            hideModal(modal.id);
        });
    });
    
    // Close modal when clicking outside
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                hideModal(this.id);
            }
        });
    });
    
    // Switch between login and signup
    if (signupLink) {
        signupLink.addEventListener('click', function(e) {
            e.preventDefault();
            hideModal('loginModal');
            showModal('signupModal');
        });
    }
    
    if (loginLink) {
        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            hideModal('signupModal');
            showModal('loginModal');
        });
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Authentication functions
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    if (!email || !password) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    try {
        showLoading(true);
        await auth.signInWithEmailAndPassword(email, password);
        hideModal('loginModal');
        showNotification('Login successful!', 'success');
        loginForm.reset();
    } catch (error) {
        console.error('Login error:', error);
        showNotification(getErrorMessage(error.code), 'error');
    } finally {
        showLoading(false);
    }
}

async function handleSignup(e) {
    e.preventDefault();
    
    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    const userType = document.getElementById('userType').value;
    
    if (!name || !email || !password || !userType) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    if (password.length < 6) {
        showNotification('Password must be at least 6 characters long', 'error');
        return;
    }
    
    try {
        showLoading(true);
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        // Update profile
        await user.updateProfile({
            displayName: name
        });
        
        // Save user data to Firestore
        await db.collection('users').doc(user.uid).set({
            name: name,
            email: email,
            userType: userType,
            isActive: true,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        hideModal('signupModal');
        showNotification('Account created successfully!', 'success');
        signupForm.reset();
    } catch (error) {
        console.error('Signup error:', error);
        showNotification(getErrorMessage(error.code), 'error');
    } finally {
        showLoading(false);
    }
}

async function handleLogout() {
    try {
        await auth.signOut();
        showNotification('Logged out successfully!', 'success');
    } catch (error) {
        console.error('Logout error:', error);
        showNotification('Error logging out', 'error');
    }
}

// Auth state change handler
async function handleAuthStateChange(user) {
    if (user) {
        currentUser = user;
        await loadUserData();
        showDashboard();
        await loadDoctors();
        await loadUserAppointments();
    } else {
        currentUser = null;
        currentUserData = null;
        hideDashboard();
    }
}

async function loadUserData() {
    if (!currentUser) return;
    
    try {
        const userDoc = await db.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists) {
            currentUserData = userDoc.data();
            const userNameElement = document.getElementById('userName');
            if (userNameElement) {
                userNameElement.textContent = currentUserData.name || currentUser.displayName || 'User';
            }
            
            // Show admin link if user is admin
            if (adminLink && (currentUserData.userType === 'admin' || currentUserData.isAdmin)) {
                adminLink.style.display = 'inline-block';
            }
        }
    } catch (error) {
        console.error('Error loading user data:', error);
    }
}

function showDashboard() {
    const sections = ['hero', 'services', 'about', 'contact'];
    sections.forEach(sectionId => {
        const section = document.getElementById(sectionId) || document.querySelector(`.${sectionId}`);
        if (section) section.style.display = 'none';
    });
    
    if (dashboard) dashboard.style.display = 'block';
    if (loginBtn) loginBtn.style.display = 'none';
}

function hideDashboard() {
    const sections = ['hero', 'services', 'about', 'contact'];
    sections.forEach(sectionId => {
        const section = document.getElementById(sectionId) || document.querySelector(`.${sectionId}`);
        if (section) {
            section.style.display = sectionId === 'hero' ? 'flex' : 'block';
        }
    });
    
    if (dashboard) dashboard.style.display = 'none';
    if (loginBtn) loginBtn.style.display = 'block';
    if (adminLink) adminLink.style.display = 'none';
}

// Doctor management
async function loadDoctors() {
    try {
        const doctorsSnapshot = await db.collection('doctors')
            .where('isActive', '==', true)
            .orderBy('name')
            .get();
        
        const doctorSelect = document.getElementById('doctorSelect');
        
        if (doctorSelect) {
            doctorSelect.innerHTML = '<option value="">Choose a doctor...</option>';
            
            if (doctorsSnapshot.empty) {                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'No doctors available';
                option.disabled = true;
                doctorSelect.appendChild(option);
                return;
            }
            
            doctorsSnapshot.forEach(doc => {
                const doctor = doc.data();
                const option = document.createElement('option');
                option.value = doc.id;
                option.textContent = `Dr. ${doctor.name} - ${doctor.specialization}`;
                doctorSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading doctors:', error);
        showNotification('Error loading doctors', 'error');
    }
}

// Appointment management
async function handleAppointmentBooking(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Please log in to book an appointment', 'error');
        return;
    }
    
    const doctorId = document.getElementById('doctorSelect').value;
    const date = document.getElementById('appointmentDate').value;
    const time = document.getElementById('appointmentTime').value;
    const reason = document.getElementById('reason').value.trim();
    
    if (!doctorId || !date || !time || !reason) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    // Check if appointment date is not in the past
    const appointmentDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (appointmentDate < today) {
        showNotification('Cannot book appointments for past dates', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        // Check for existing appointment at the same time
        const existingAppointment = await db.collection('appointments')
            .where('doctorId', '==', doctorId)
            .where('date', '==', date)
            .where('time', '==', time)
            .where('status', 'in', ['pending', 'confirmed'])
            .get();
            
        if (!existingAppointment.empty) {
            showNotification('This time slot is already booked. Please choose another time.', 'error');
            return;
        }
        
        // Get doctor data
        const doctorDoc = await db.collection('doctors').doc(doctorId).get();
        if (!doctorDoc.exists) {
            showNotification('Selected doctor not found', 'error');
            return;
        }
        const doctorData = doctorDoc.data();
        
        // Create appointment
        await db.collection('appointments').add({
            patientId: currentUser.uid,
            patientName: currentUserData.name,
            patientEmail: currentUserData.email,
            doctorId: doctorId,
            doctorName: doctorData.name,
            doctorSpecialization: doctorData.specialization,
            date: date,
            time: time,
            reason: reason,
            status: 'pending',
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        showNotification('Appointment booked successfully!', 'success');
        appointmentForm.reset();
        await loadUserAppointments();
    } catch (error) {
        console.error('Error booking appointment:', error);
        showNotification('Error booking appointment. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function loadUserAppointments() {
    if (!currentUser) return;
    
    try {
        const appointmentsSnapshot = await db.collection('appointments')
            .where('patientId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .get();
        
        const appointmentsList = document.getElementById('appointmentsList');
        if (appointmentsList) {
            appointmentsList.innerHTML = '';
            
            if (appointmentsSnapshot.empty) {
                appointmentsList.innerHTML = '<div class="no-appointments"><p>No appointments found.</p></div>';
                return;
            }
            
            appointmentsSnapshot.forEach(doc => {
                const appointment = doc.data();
                const appointmentElement = createAppointmentElement(appointment, doc.id);
                appointmentsList.appendChild(appointmentElement);
            });
        }
    } catch (error) {
        console.error('Error loading appointments:', error);
        const appointmentsList = document.getElementById('appointmentsList');
        if (appointmentsList) {
            appointmentsList.innerHTML = '<div class="error-message"><p>Error loading appointments</p></div>';
        }
    }
}

function createAppointmentElement(appointment, appointmentId) {
    const div = document.createElement('div');
    div.className = 'appointment-item';
    
    const appointmentDate = new Date(appointment.date);
    const isUpcoming = appointmentDate >= new Date() && appointment.status !== 'cancelled' && appointment.status !== 'completed';
    
    div.innerHTML = `
        <div class="appointment-header">
            <h4>Dr. ${appointment.doctorName}</h4>
            <span class="status-badge status-${appointment.status}">${appointment.status.toUpperCase()}</span>
        </div>
        <div class="appointment-details">
            <p><strong>Specialization:</strong> ${appointment.doctorSpecialization}</p>
            <p><strong>Date:</strong> ${formatDate(appointment.date)}</p>
            <p><strong>Time:</strong> ${appointment.time}</p>
            <p><strong>Reason:</strong> ${appointment.reason}</p>
            ${appointment.createdAt ? `<p><strong>Booked:</strong> ${formatTimestamp(appointment.createdAt)}</p>` : ''}
        </div>
        ${appointment.status === 'pending' && isUpcoming ? `
            <div class="appointment-actions">
                <button class="btn-danger" onclick="cancelAppointment('${appointmentId}')">Cancel Appointment</button>
            </div>
        ` : ''}
    `;
    return div;
}

async function cancelAppointment(appointmentId) {
    if (!confirm('Are you sure you want to cancel this appointment?')) {
        return;
    }
    
    try {
        showLoading(true);
        await db.collection('appointments').doc(appointmentId).update({
            status: 'cancelled',
            cancelledAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        showNotification('Appointment cancelled successfully', 'success');
        await loadUserAppointments();
    } catch (error) {
        console.error('Error cancelling appointment:', error);
        showNotification('Error cancelling appointment', 'error');
    } finally {
        showLoading(false);
    }
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatTimestamp(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function getErrorMessage(errorCode) {
    const errorMessages = {
        'auth/user-not-found': 'No account found with this email address.',
        'auth/wrong-password': 'Incorrect password.',
        'auth/email-already-in-use': 'An account with this email already exists.',
        'auth/weak-password': 'Password should be at least 6 characters.',
        'auth/invalid-email': 'Please enter a valid email address.',
        'auth/too-many-requests': 'Too many failed attempts. Please try again later.',
        'auth/network-request-failed': 'Network error. Please check your connection.',
    };
    
    return errorMessages[errorCode] || 'An error occurred. Please try again.';
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button class="notification-close">×</button>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        z-index: 10000;
        max-width: 350px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        display: flex;
        justify-content: space-between;
        align-items: center;
        animation: slideInRight 0.3s ease;
        font-weight: 500;
    `;
    
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    };
    
    notification.style.backgroundColor = colors[type] || colors.info;
    
    if (type === 'warning') {
        notification.style.color = '#333';
    }
    
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.style.cssText = `
        background: none;
        border: none;
        color: inherit;
        font-size: 1.2rem;
        cursor: pointer;
        margin-left: 1rem;
        padding: 0;
        line-height: 1;
    `;
    
    closeBtn.addEventListener('click', () => {
        notification.remove();
    });
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function showLoading(show) {
    let loader = document.getElementById('globalLoader');
    
    if (show) {
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'globalLoader';
            loader.innerHTML = `
                <div class="loader-backdrop">
                    <div class="loader-spinner"></div>
                    <p>Loading...</p>
                </div>
            `;
            loader.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
            `;
            document.body.appendChild(loader);
        }
        loader.style.display = 'flex';
    } else {
        if (loader) {
            loader.style.display = 'none';
        }
    }
}

// Initialize sample data
async function initializeSampleData() {
    try {
        // Check if doctors already exist
        const doctorsSnapshot = await db.collection('doctors').limit(1).get();
        
        if (doctorsSnapshot.empty) {
            console.log('Initializing sample doctors...');
            await initializeSampleDoctors();
        }
        
        // Check if admin user exists
        const adminQuery = await db.collection('users').where('userType', '==', 'admin').limit(1).get();
        
        if (adminQuery.empty) {
            console.log('Initializing admin user...');
            await initializeAdminUser();
        }
    } catch (error) {
        console.error('Error initializing sample data:', error);
    }
}

async function initializeSampleDoctors() {
    try {
        const sampleDoctors = [
            {
                name: 'John Doe',
                email: 'john.doe@eclinic.gh',
                phone: '+233 123 456 789',
                specialization: 'General Medicine',
                experience: 10,
                bio: 'Experienced general practitioner with focus on preventive care.',
                isActive: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            },
            {
                name: 'Jane Smith',
                email: 'jane.smith@eclinic.gh',
                phone: '+233 987 654 321',
                specialization: 'Cardiology',
                experience: 15,
                bio: 'Specialist in cardiovascular diseases and heart health.',
                isActive: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            },
            {
                name: 'Michael Johnson',
                email: 'michael.johnson@eclinic.gh',
                phone: '+233 555 123 456',
                specialization: 'Pediatrics',
                experience: 8,
                bio: 'Dedicated pediatrician caring for children and adolescents.',
                isActive: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            },
            {
                name: 'Sarah Wilson',
                email: 'sarah.wilson@eclinic.gh',
                phone: '+233 444 789 123',
                specialization: 'Dermatology',
                experience: 12,
                bio: 'Expert in skin conditions and cosmetic dermatology.',
                isActive: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            },
            {
                name: 'David Brown',
                email: 'david.brown@eclinic.gh',
                phone: '+233 333 456 789',
                specialization: 'Orthopedics',
                experience: 18,
                bio: 'Orthopedic surgeon specializing in joint and bone disorders.',
                isActive: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            }
        ];
        
        const batch = db.batch();
        sampleDoctors.forEach(doctor => {
            const docRef = db.collection('doctors').doc();
            batch.set(docRef, doctor);
        });
        
        await batch.commit();
        console.log('Sample doctors initialized successfully');
    } catch (error) {
        console.error('Error initializing sample doctors:', error);
    }
}

async function initializeAdminUser() {
    try {
        const adminEmail = 'admin@eclinic.gh';
        const adminPassword = 'admin123456';
        
        // Create admin user
        const userCredential = await auth.createUserWithEmailAndPassword(adminEmail, adminPassword);
        const user = userCredential.user;
        
        await user.updateProfile({
            displayName: 'System Administrator'
        });
        
        await db.collection('users').doc(user.uid).set({
            name: 'System Administrator',
            email: adminEmail,
            userType: 'admin',
            isAdmin: true,
            isActive: true,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        console.log('Default admin user created successfully');
        console.log('Admin credentials: admin@eclinic.gh / admin123456');
        
        // Sign out the admin user so it doesn't interfere with normal login
        await auth.signOut();
    } catch (error) {
        if (error.code === 'auth/email-already-in-use') {
            console.log('Admin user already exists');
        } else {
            console.error('Error creating admin user:', error);
        }
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .loader-backdrop {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .loader-spinner {
        width: 40px;
        height: 40px;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #007bff;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto 1rem;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .no-appointments, .error-message {
        text-align: center;
        padding: 2rem;
        color: #666;
        font-style: italic;
    }
    
    .btn-danger {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.9rem;
        transition: background-color 0.3s ease;
    }
    
    .btn-danger:hover {
        background-color: #c82333;
    }
`;
document.head.appendChild(style);

// Export functions for global access
window.cancelAppointment = cancelAppointment

// Admin-specific functionality
let adminUser = null;
let currentAdminData = null;

document.addEventListener('DOMContentLoaded', function() {
    // Check authentication and admin status
    auth.onAuthStateChanged(async (user) => {
        if (user) {
            const isAdmin = await checkAdminStatus(user.uid);
            if (isAdmin) {
                adminUser = user;
                await loadAdminData();
                initializeAdminDashboard();
            } else {
                showNotification('Access denied. Admin privileges required.', 'error');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 2000);
            }
        } else {
            window.location.href = 'index.html';
        }
    });
    
    setupAdminEventListeners();
});

async function checkAdminStatus(userId) {
    try {
        const userDoc = await db.collection('users').doc(userId).get();
        if (userDoc.exists) {
            const userData = userDoc.data();
            return userData.userType === 'admin' || userData.isAdmin === true;
        }
        return false;
    } catch (error) {
        console.error('Error checking admin status:', error);
        return false;
    }
}

async function loadAdminData() {
    if (!adminUser) return;
    
    try {
        const userDoc = await db.collection('users').doc(adminUser.uid).get();
        if (userDoc.exists) {
            currentAdminData = userDoc.data();
        }
    } catch (error) {
        console.error('Error loading admin data:', error);
    }
}

function setupAdminEventListeners() {
    // Navigation
    setupAdminNavigation();
    
    // Logout
    const adminLogoutBtn = document.getElementById('adminLogoutBtn');
    if (adminLogoutBtn) {
        adminLogoutBtn.addEventListener('click', handleAdminLogout);
    }
    
    // Modals and forms
    setupAddDoctorModal();
    setupEditDoctorModal();
    setupFilters();
    
    // Settings
    setupSettingsHandlers();
}

function setupAdminNavigation() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active menu item
            menuItems.forEach(mi => mi.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding section
            const sections = document.querySelectorAll('.admin-section');
            sections.forEach(section => section.classList.remove('active'));
            
            const targetSection = this.getAttribute('data-section');
            const section = document.getElementById(targetSection);
            if (section) {
                section.classList.add('active');
                loadSectionData(targetSection);
            }
        });
    });
}

async function initializeAdminDashboard() {
    // Update admin name
    const adminNameElement = document.getElementById('adminName');
    if (adminNameElement && adminUser) {
        const displayName = currentAdminData?.name || adminUser.displayName || 'Admin';
        adminNameElement.textContent = `Welcome, ${displayName}`;
    }
    
    // Load initial data
    await loadSectionData('overview');
}

async function loadSectionData(section) {
    try {
        showLoading(true);
        
        switch (section) {
            case 'overview':
                await loadOverviewData();
                break;
            case 'users':
                await loadUsersData();
                break;
            case 'appointments':
                await loadAppointmentsData();
                break;
            case 'doctors':
                await loadDoctorsData();
                break;
            case 'settings':
                loadSettingsData();
                break;
        }
    } catch (error) {
        console.error(`Error loading ${section} data:`, error);
        showNotification(`Error loading ${section} data`, 'error');
    } finally {
        showLoading(false);
    }
}

async function loadOverviewData() {
    try {
        // Load statistics
        const [usersSnapshot, doctorsSnapshot, appointmentsSnapshot, pendingSnapshot] = await Promise.all([
            db.collection('users').get(),
            db.collection('doctors').get(),
            db.collection('appointments').get(),
            db.collection('appointments').where('status', '==', 'pending').get()
        ]);
        
        document.getElementById('totalUsers').textContent = usersSnapshot.size;
        document.getElementById('totalDoctors').textContent = doctorsSnapshot.size;
        document.getElementById('totalAppointments').textContent = appointmentsSnapshot.size;
        document.getElementById('pendingAppointments').textContent = pendingSnapshot.size;
        
        // Load recent activity
        await loadRecentActivity();
        
    } catch (error) {
        console.error('Error loading overview data:', error);
        throw error;
    }
}

async function loadRecentActivity() {
    try {
        const recentAppointments = await db.collection('appointments')
            .orderBy('createdAt', 'desc')
            .limit(5)
            .get();
            
        const activityContainer = document.getElementById('recentActivity');
        if (activityContainer) {
            activityContainer.innerHTML = '';
            
            if (recentAppointments.empty) {
                activityContainer.innerHTML = '<p>No recent activity</p>';
                return;
            }
            
            recentAppointments.forEach(doc => {
                const appointment = doc.data();
                const activityItem = document.createElement('div');
                activityItem.className = 'activity-item';
                activityItem.innerHTML = `
                    <div class="activity-content">
                        <p><strong>${appointment.patientName}</strong> booked an appointment with <strong>Dr. ${appointment.doctorName}</strong></p>
                        <small>${formatTimestamp(appointment.createdAt)}</small>
                    </div>
                    <span class="status-badge status-${appointment.status}">${appointment.status}</span>
                `;
                activityContainer.appendChild(activityItem);
            });
        }
    } catch (error) {
        console.error('Error loading recent activity:', error);
    }
}

async function loadUsersData() {
    try {
        const usersSnapshot = await db.collection('users')
            .orderBy('createdAt', 'desc')
            .get();
            
        const tbody = document.getElementById('usersTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (usersSnapshot.empty) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No users found</td></tr>';
            return;
        }
        
        usersSnapshot.forEach(doc => {
            const user = doc.data();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.name || 'N/A'}</td>
                <td>${user.email}</td>
                <td><span class="status-badge status-${user.userType}">${user.userType}</span></td>
                <td>${formatTimestamp(user.createdAt)}</td>
                <td><span class="status-badge status-${user.isActive ? 'active' : 'inactive'}">${user.isActive ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn-secondary btn-sm" onclick="toggleUserStatus('${doc.id}', ${user.isActive})">
                        ${user.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading users data:', error);
        throw error;
    }
}

async function loadAppointmentsData() {
    try {
        const appointmentsSnapshot = await db.collection('appointments')
            .orderBy('createdAt', 'desc')
            .get();
            
        const tbody = document.getElementById('appointmentsTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (appointmentsSnapshot.empty) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No appointments found</td></tr>';
            return;
        }
        
        appointmentsSnapshot.forEach(doc => {
            const appointment = doc.data();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${appointment.patientName}</td>
                <td>Dr. ${appointment.doctorName}</td>
                <td>${formatDate(appointment.date)}</td>
                <td>${appointment.time}</td>
                <td><span class="status-badge status-${appointment.status}">${appointment.status}</span></td>
                <td>
                    <select class="status-select" onchange="updateAppointmentStatus('${doc.id}', this.value)">
                        <option value="pending" ${appointment.status === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="confirmed" ${appointment.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                        <option value="cancelled" ${appointment.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                        <option value="completed" ${appointment.status === 'completed' ? 'selected' : ''}>Completed</option>
                    </select>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading appointments data:', error);
        throw error;
    }
}

async function loadDoctorsData() {
    try {
        const doctorsSnapshot = await db.collection('doctors')
            .orderBy('createdAt', 'desc')
            .get();
            
        const tbody = document.getElementById('doctorsTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (doctorsSnapshot.empty) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No doctors found</td></tr>';
            return;
        }
        
        doctorsSnapshot.forEach(doc => {
            const doctor = doc.data();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>Dr. ${doctor.name}</td>
                <td>${doctor.specialization}</td>
                <td>${doctor.email}</td>
                <td>${doctor.phone}</td>
                <td>${doctor.experience} years</td>
                <td><span class="status-badge status-${doctor.isActive ? 'active' : 'inactive'}">${doctor.isActive ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn-secondary btn-sm" onclick="editDoctor('${doc.id}')">Edit</button>
                    <button class="btn-secondary btn-sm" onclick="toggleDoctorStatus('${doc.id}', ${doctor.isActive})">
                        ${doctor.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading doctors data:', error);
        throw error;
    }
}

function loadSettingsData() {
    // Settings data is mostly static, no async loading needed
    console.log('Settings section loaded');
}

// Modal and form handlers
function setupAddDoctorModal() {
    const addDoctorBtn = document.getElementById('addDoctorBtn');
    const addDoctorModal = document.getElementById('addDoctorModal');
    const addDoctorForm = document.getElementById('addDoctorForm');
    const closeBtn = addDoctorModal?.querySelector('.close');
    
    if (addDoctorBtn && addDoctorModal) {
        addDoctorBtn.addEventListener('click', () => {
            addDoctorModal.style.display = 'block';
        });
    }
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            addDoctorModal.style.display = 'none';
        });
    }
    
    if (addDoctorForm) {
        addDoctorForm.addEventListener('submit', handleAddDoctor);
    }
    
    // Close modal when clicking outside
    if (addDoctorModal) {
        addDoctorModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    }
}

function setupEditDoctorModal() {
    const editDoctorModal = document.getElementById('editDoctorModal');
    const editDoctorForm = document.getElementById('editDoctorForm');
    const closeBtn = editDoctorModal?.querySelector('.close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            editDoctorModal.style.display = 'none';
        });
    }
    
    if (editDoctorForm) {
        editDoctorForm.addEventListener('submit', handleEditDoctor);
    }
    
    // Close modal when clicking outside
    if (editDoctorModal) {
        editDoctorModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    }
}

function setupFilters() {
    // User filters

    const userSearch = document.getElementById('userSearch');
    const userTypeFilter = document.getElementById('userTypeFilter');
    
    if (userSearch) {
        userSearch.addEventListener('input', debounce(filterUsers, 300));
    }
    
    if (userTypeFilter) {
        userTypeFilter.addEventListener('change', filterUsers);
    }
    
    // Appointment filters
    const appointmentDateFilter = document.getElementById('appointmentDateFilter');
    const appointmentStatusFilter = document.getElementById('appointmentStatusFilter');
    
    if (appointmentDateFilter) {
        appointmentDateFilter.addEventListener('change', filterAppointments);
    }
    
    if (appointmentStatusFilter) {
        appointmentStatusFilter.addEventListener('change', filterAppointments);
    }
    
    // Doctor search
    const doctorSearch = document.getElementById('doctorSearch');
    if (doctorSearch) {
        doctorSearch.addEventListener('input', debounce(filterDoctors, 300));
    }
}

function setupSettingsHandlers() {
    const clinicInfoForm = document.getElementById('clinicInfoForm');
    const backupDataBtn = document.getElementById('backupDataBtn');
    const clearLogsBtn = document.getElementById('clearLogsBtn');
    const systemStatusBtn = document.getElementById('systemStatusBtn');
    
    if (clinicInfoForm) {
        clinicInfoForm.addEventListener('submit', handleClinicInfoUpdate);
    }
    
    if (backupDataBtn) {
        backupDataBtn.addEventListener('click', handleBackupData);
    }
    
    if (clearLogsBtn) {
        clearLogsBtn.addEventListener('click', handleClearLogs);
    }
    
    if (systemStatusBtn) {
        systemStatusBtn.addEventListener('click', handleSystemStatus);
    }
}

// Event handlers
async function handleAddDoctor(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('doctorName').value.trim(),
        email: document.getElementById('doctorEmail').value.trim(),
        phone: document.getElementById('doctorPhone').value.trim(),
        specialization: document.getElementById('doctorSpecialization').value,
        experience: parseInt(document.getElementById('doctorExperience').value),
        bio: document.getElementById('doctorBio').value.trim(),
        isActive: true,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    
    // Validation
    if (!formData.name || !formData.email || !formData.phone || !formData.specialization || !formData.experience) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    if (formData.experience < 0 || formData.experience > 50) {
        showNotification('Experience must be between 0 and 50 years', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        // Check if doctor email already exists
        const existingDoctor = await db.collection('doctors')
            .where('email', '==', formData.email)
            .get();
            
        if (!existingDoctor.empty) {
            showNotification('A doctor with this email already exists', 'error');
            return;
        }
        
        await db.collection('doctors').add(formData);
        
        showNotification('Doctor added successfully!', 'success');
        document.getElementById('addDoctorModal').style.display = 'none';
        document.getElementById('addDoctorForm').reset();
        
        // Reload doctors data
        await loadDoctorsData();
        
    } catch (error) {
        console.error('Error adding doctor:', error);
        showNotification('Error adding doctor. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function handleEditDoctor(e) {
    e.preventDefault();
    
    const doctorId = document.getElementById('editDoctorId').value;
    const formData = {
        name: document.getElementById('editDoctorName').value.trim(),
        email: document.getElementById('editDoctorEmail').value.trim(),
        phone: document.getElementById('editDoctorPhone').value.trim(),
        specialization: document.getElementById('editDoctorSpecialization').value,
        experience: parseInt(document.getElementById('editDoctorExperience').value),
        bio: document.getElementById('editDoctorBio').value.trim(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    
    // Validation
    if (!formData.name || !formData.email || !formData.phone || !formData.specialization || !formData.experience) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        await db.collection('doctors').doc(doctorId).update(formData);
        
        showNotification('Doctor updated successfully!', 'success');
        document.getElementById('editDoctorModal').style.display = 'none';
        
        // Reload doctors data
        await loadDoctorsData();
        
    } catch (error) {
        console.error('Error updating doctor:', error);
        showNotification('Error updating doctor. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function handleClinicInfoUpdate(e) {
    e.preventDefault();
    
    const clinicData = {
        name: document.getElementById('clinicName').value.trim(),
        address: document.getElementById('clinicAddress').value.trim(),
        phone: document.getElementById('clinicPhone').value.trim(),
        email: document.getElementById('clinicEmail').value.trim(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    
    try {
        showLoading(true);
        
        // Save to settings collection
        await db.collection('settings').doc('clinic').set(clinicData, { merge: true });
        
        showNotification('Clinic information updated successfully!', 'success');
        
    } catch (error) {
        console.error('Error updating clinic info:', error);
        showNotification('Error updating clinic information', 'error');
    } finally {
        showLoading(false);
    }
}

function handleBackupData() {
    showNotification('Backup functionality would be implemented here', 'info');
}

function handleClearLogs() {
    if (confirm('Are you sure you want to clear all logs? This action cannot be undone.')) {
        showNotification('Logs cleared successfully', 'success');
    }
}

function handleSystemStatus() {
    showNotification('System is running normally', 'success');
}

async function handleAdminLogout() {
    try {
        await auth.signOut();
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Error logging out:', error);
        showNotification('Error logging out', 'error');
    }
}

// Action functions
async function editDoctor(doctorId) {
    try {
        const doctorDoc = await db.collection('doctors').doc(doctorId).get();
        if (!doctorDoc.exists) {
            showNotification('Doctor not found', 'error');
            return;
        }
        
        const doctor = doctorDoc.data();
        
        // Populate edit form
        document.getElementById('editDoctorId').value = doctorId;
        document.getElementById('editDoctorName').value = doctor.name;
        document.getElementById('editDoctorEmail').value = doctor.email;
        document.getElementById('editDoctorPhone').value = doctor.phone;
        document.getElementById('editDoctorSpecialization').value = doctor.specialization;
        document.getElementById('editDoctorExperience').value = doctor.experience;
        document.getElementById('editDoctorBio').value = doctor.bio || '';
        
        // Show modal
        document.getElementById('editDoctorModal').style.display = 'block';
        
    } catch (error) {
        console.error('Error loading doctor data:', error);
        showNotification('Error loading doctor data', 'error');
    }
}

async function toggleDoctorStatus(doctorId, currentStatus) {
    const newStatus = !currentStatus;
    const action = newStatus ? 'activate' : 'deactivate';
    
    if (!confirm(`Are you sure you want to ${action} this doctor?`)) {
        return;
    }
    
    try {
        showLoading(true);
        
        await db.collection('doctors').doc(doctorId).update({
            isActive: newStatus,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        showNotification(`Doctor ${action}d successfully`, 'success');
        await loadDoctorsData();
        
    } catch (error) {
        console.error(`Error ${action}ing doctor:`, error);
        showNotification(`Error ${action}ing doctor`, 'error');
    } finally {
        showLoading(false);
    }
}

async function toggleUserStatus(userId, currentStatus) {
    const newStatus = !currentStatus;
    const action = newStatus ? 'activate' : 'deactivate';
    
    if (!confirm(`Are you sure you want to ${action} this user?`)) {
        return;
    }
    
    try {
        showLoading(true);
        
        await db.collection('users').doc(userId).update({
            isActive: newStatus,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        showNotification(`User ${action}d successfully`, 'success');
        await loadUsersData();
        
    } catch (error) {
        console.error(`Error ${action}ing user:`, error);
        showNotification(`Error ${action}ing user`, 'error');
    } finally {
        showLoading(false);
    }
}

async function updateAppointmentStatus(appointmentId, newStatus) {
    try {
        showLoading(true);
        
        await db.collection('appointments').doc(appointmentId).update({
            status: newStatus,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        showNotification('Appointment status updated successfully', 'success');
        
    } catch (error) {
        console.error('Error updating appointment status:', error);
        showNotification('Error updating appointment status', 'error');
        // Reload to reset the select value
        await loadAppointmentsData();
    } finally {
        showLoading(false);
    }
}

// Filter functions
async function filterUsers() {
    const searchTerm = document.getElementById('userSearch').value.toLowerCase();
    const typeFilter = document.getElementById('userTypeFilter').value;
    
    try {
        let query = db.collection('users');
        
        if (typeFilter) {
            query = query.where('userType', '==', typeFilter);
        }
        
        const snapshot = await query.orderBy('createdAt', 'desc').get();
        const tbody = document.getElementById('usersTableBody');
        
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        let filteredUsers = [];
        snapshot.forEach(doc => {
            const user = doc.data();
            const matchesSearch = !searchTerm || 
                user.name?.toLowerCase().includes(searchTerm) ||
                user.email?.toLowerCase().includes(searchTerm);
                
            if (matchesSearch) {
                filteredUsers.push({ id: doc.id, data: user });
            }
        });
        
        if (filteredUsers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No users found</td></tr>';
            return;
        }
        
        filteredUsers.forEach(({ id, data: user }) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.name || 'N/A'}</td>
                <td>${user.email}</td>
                <td><span class="status-badge status-${user.userType}">${user.userType}</span></td>
                <td>${formatTimestamp(user.createdAt)}</td>
                <td><span class="status-badge status-${user.isActive ? 'active' : 'inactive'}">${user.isActive ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn-secondary btn-sm" onclick="toggleUserStatus('${id}', ${user.isActive})">
                        ${user.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
    } catch (error) {
        console.error('Error filtering users:', error);
    }
}

async function filterAppointments() {
    const dateFilter = document.getElementById('appointmentDateFilter').value;
    const statusFilter = document.getElementById('appointmentStatusFilter').value;
    
    try {
        let query = db.collection('appointments');
        
        if (statusFilter) {
            query = query.where('status', '==', statusFilter);
        }
        
        if (dateFilter) {
            query = query.where('date', '==', dateFilter);
        }
        
        const snapshot = await query.orderBy('createdAt', 'desc').get();
        const tbody = document.getElementById('appointmentsTableBody');
        
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (snapshot.empty) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No appointments found</td></tr>';
            return;
        }
        
        snapshot.forEach(doc => {
            const appointment = doc.data();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${appointment.patientName}</td>
                <td>Dr. ${appointment.doctorName}</td>
                <td>${formatDate(appointment.date)}</td>
                <td>${appointment.time}</td>
                <td><span class="status-badge status-${appointment.status}">${appointment.status}</span></td>
                <td>
                    <select class="status-select" onchange="updateAppointmentStatus('${doc.id}', this.value)">
                        <option value="pending" ${appointment.status === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="confirmed" ${appointment.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                        <option value="cancelled" ${appointment.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                        <option value="completed" ${appointment.status === 'completed' ? 'selected' : ''}>Completed</option>
                    </select>
                </td>
            `;
            tbody.appendChild(row);
        });
        
    } catch (error) {
        console.error('Error filtering appointments:', error);
    }
}

async function filterDoctors() {
    const searchTerm = document.getElementById('doctorSearch').value.toLowerCase();
    
    try {
        const snapshot = await db.collection('doctors')
            .orderBy('createdAt', 'desc')
            .get();
            
        const tbody = document.getElementById('doctorsTableBody');
        
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        let filteredDoctors = [];
        snapshot.forEach(doc => {
            const doctor = doc.data();
            const matchesSearch = !searchTerm || 
                doctor.name?.toLowerCase().includes(searchTerm) ||
                doctor.specialization?.toLowerCase().includes(searchTerm) ||
                doctor.email?.toLowerCase().includes(searchTerm);
                
            if (matchesSearch) {
                filteredDoctors.push({ id: doc.id, data: doctor });
            }
        });
        
        if (filteredDoctors.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No doctors found</td></tr>';
            return;
        }
        
        filteredDoctors.forEach(({ id, data: doctor }) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>Dr. ${doctor.name}</td>
                <td>${doctor.specialization}</td>
                <td>${doctor.email}</td>
                <td>${doctor.phone}</td>
                <td>${doctor.experience} years</td>
                <td><span class="status-badge status-${doctor.isActive ? 'active' : 'inactive'}">${doctor.isActive ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn-secondary btn-sm" onclick="editDoctor('${id}')">Edit</button>
                    <button class="btn-secondary btn-sm" onclick="toggleDoctorStatus('${id}', ${doctor.isActive})">
                        ${doctor.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
    } catch (error) {
        console.error('Error filtering doctors:', error);
    }
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for global access
window.editDoctor = editDoctor;
window.toggleDoctorStatus = toggleDoctorStatus;
window.toggleUserStatus = toggleUserStatus;
window.updateAppointmentStatus = updateAppointmentStatus;
